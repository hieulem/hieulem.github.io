We use a threshold of 150 for both SBU and UCF testing set.
